package examples.pl.plugins.integration.inbound.fileadapter;

import aQute.bnd.annotation.component.Activate;
import aQute.bnd.annotation.component.Component;
import gw.api.integration.inbound.files.LineProcessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(provide = SampleLineProcessor.class)
public class SampleLineProcessor implements LineProcessor {
  private final static Logger log = LoggerFactory.getLogger( SampleLineProcessor.class );

  @Activate
  public void init() {
    log.info( "SampleLineProcessor init()" );
  }

  @Override
  public void processLine( final String line ) {
    log.info( "{}.processLine: {}", line );
  }

}
