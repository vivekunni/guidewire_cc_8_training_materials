package examples.pl.plugins.integration.inbound.jmsadapter;

import aQute.bnd.annotation.component.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jms.Message;
import javax.jms.MessageListener;

@Component(provide = SampleJMSMessageListener.class)
public class SampleJMSMessageListener implements MessageListener {
  private final static Logger log = LoggerFactory.getLogger( SampleJMSMessageListener.class );

  /* (non-Javadoc)
   * @see javax.jms.MessageListener#onMessage(javax.jms.Message)
   */
  @Override
  public void onMessage( Message message ) {
    log.info( "{}.onMessage: {}", this, message );
  }

}
