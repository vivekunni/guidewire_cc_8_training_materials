package examples.pl.plugins.management;

import gw.plugin.management.GWMBean;
import gw.plugin.management.ManagementAuthorizationCallbackHandler;
import gw.plugin.management.Notification;
import gw.plugin.management.NotificationSenderMarker;
import aQute.bnd.annotation.component.Activate;
import aQute.bnd.annotation.component.Component;
import aQute.bnd.annotation.component.ConfigurationPolicy;
import gw.pl.logging.LoggerCategory;
import gw.plugin.management.ManagementPlugin;

import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.ObjectName;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

/**
 * Example management plugin using JMX.
 */
@Component(configurationPolicy = ConfigurationPolicy.require)
public class JMXManagementPlugin implements ManagementPlugin {

  protected MBeanServer _mBeanServer;
  protected GWMBeanWrapper _notificationSender;
  protected int _rmiPort = 1099; // Default to 1099
  protected JSR160Connector _connector;
  protected ManagementAuthorizationCallbackHandler _callbackHandler;

  @Activate
  void start(Map<?, ?> properties) {
    if (properties.containsKey("rmiPort")) {
      _rmiPort = Integer.parseInt((String) properties.get("rmiPort"));
    } else {
      LoggerCategory.PLUGIN.error("No rmiPort parameter defined for JMXManagementPlugin");
    }

    LoggerCategory.PLUGIN.info("Starting JSR 160 connector on port " + _rmiPort);
  }

  @Override
  public void start() {
    _mBeanServer = MBeanServerFactory.createMBeanServer();
    startConnectors();
  }

  @Override
  public void stop() {
    if (_mBeanServer != null) {
      stopConnectors();
      MBeanServerFactory.releaseMBeanServer(_mBeanServer);
    }
  }

  @Override
  public void setAuthorizationCallbackHandler(ManagementAuthorizationCallbackHandler handler) {
    _callbackHandler = handler;
  }

  @Override
  public void registerBean(GWMBean bean) {
    ArrayList<MBeanServer> mBeanServers = MBeanServerFactory.findMBeanServer(null);
    for (MBeanServer mBeanServer : mBeanServers) {
      try {
        GWMBeanWrapper beanWrapper = new GWMBeanWrapper(bean);
        if (bean instanceof NotificationSenderMarker) {
          _notificationSender = beanWrapper;
        }
        mBeanServer.registerMBean(beanWrapper, ObjectName.getInstance(bean.getBeanName()));
      } catch (Exception e) {
        LoggerCategory.PLUGIN.error("Error registering MBean " + bean.getBeanName()  + " on port " + _rmiPort, e);
      }
    }
  }

  @Override
  public void unregisterBean(GWMBean bean) {
    ArrayList<MBeanServer> mBeanServers = MBeanServerFactory.findMBeanServer(null);
    for (MBeanServer mBeanServer : mBeanServers) {
      try {
        mBeanServer.unregisterMBean(ObjectName.getInstance(bean.getBeanName()));
      } catch (Exception e) {
        LoggerCategory.PLUGIN.error("Error unregistering MBean " + bean.getBeanName() + " on port " + _rmiPort, e);
      }
    }
  }

  @Override
  public void unregisterBeanByNamePrefix(String pattern) {
    ArrayList<MBeanServer> mBeanServers = MBeanServerFactory.findMBeanServer(null);
    for (MBeanServer mBeanServer : mBeanServers) {
      try {
        Set<ObjectName> names = mBeanServer.queryNames(new ObjectName(pattern + "*"), null);
        for (ObjectName name : names) {
          mBeanServer.unregisterMBean(name);
        }
      } catch (Exception e) {
        LoggerCategory.PLUGIN.error("Error unregistering beans with pattern " + pattern + "*" + " on port " + _rmiPort, e);
      }
    }
  }

  @Override
  public void sendNotification(Notification notification) {
    if (_notificationSender != null) {
      _notificationSender.sendNotification(new javax.management.Notification(notification.getType(), notification.getSource(), notification.getSequenceNumber(), notification.getMessage()));
    }
  }

  /**
   * Subclasser hook for starting additional connectors.  By default this just starts the JSR160 connector, but it
   * can be overridden to do something else instead or in addition to that.
   */
  protected void startConnectors() {
    startJSR160Connector();
  }

  /**
   * Subclasser hook for stopping additional connectors.  By default this just stops the JSR160 connector, but it
   * can be overridden to do something else instead or in addition to that.  This ought to stop anything started
   * in the startConnectors method.
   */
  protected void stopConnectors() {
    stopJSR160Connector();
  }

  protected void startJSR160Connector() {
    try {
      _connector = new JSR160Connector(_rmiPort, _callbackHandler);
      _connector.registerAdapter(_mBeanServer);
    } catch (Exception e) {
      throw new RuntimeException("Error registering JSR160 connector on port " + _rmiPort, e);
    }
  }

  protected void stopJSR160Connector() {
    try {
      _connector.unregisterAdapter(_mBeanServer);
    } catch (Exception e) {
      throw new RuntimeException("Error unregistering JSR160 connector on port " + _rmiPort, e);
    }
  }
}
